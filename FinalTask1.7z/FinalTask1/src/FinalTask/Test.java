package FinalTask;

import java.io.File;

import static org.junit.Assert.*;

public class Test {

    String path="C:\\test\\NoteBookKek.txt";

    @org.junit.Test
    public void addNote() throws Exception {
        File f = new File(path);
        NoteBook tester = new NoteBook(path);

        long sizeBefore = f.length();
        tester.add("test");
        long sizeAfter = f.length();

        assertTrue("File size didn't increase after adding a note!", sizeAfter > sizeBefore);
    }

    @org.junit.Test
    public void removeNote() throws Exception {
        File f = new File(path);
        NoteBook tester = new NoteBook(path);

        tester.add("test");
        long sizeBefore = f.length();
        tester.delete(0);
        long sizeAfter = f.length();
        assertTrue("File size didn't decrease after removing a note!", sizeAfter < sizeBefore);
    }

}