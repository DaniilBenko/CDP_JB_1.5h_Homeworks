package FinalTask;
import java.nio.file.*;
import java.util.Date;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;


public class NoteBook {

        public void createNoteBook(){
            try{
                String path="C:\\test\\NoteBookKek.txt";
                File file = new File(path);
                if (!file.exists()) {
                    file.createNewFile();
                }
            }
            catch(Exception e){
                System.out.println(e);
            }
        }

        public void add(String note, Date data){
            Note mynote = new Note(note, data);
            String path="C:\\test\\NoteBookKek.txt";
            try {
                BufferedWriter bw;
                FileWriter fw;

                fw = new FileWriter(path, true);
                bw = new BufferedWriter(fw);

                bw.write(mynote.toString());
                bw.newLine();

                bw.close();
                fw.close();
                System.out.println("Note created!\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    public void delete(int number){
        String path="C:\\test\\NoteBookKek.txt";
        String readLine;
        int count = 0;
        List<String> array = new ArrayList<String>();
        try {
            BufferedReader b = new BufferedReader(new FileReader(path));

            while ((readLine = b.readLine()) != null) {

                if (count != number) {
                    array.add(readLine);
                }
                count++;
            }

            if (count < number) {
                System.out.println("There is no note with that number\n");
            } else {
                System.out.println("The note has been removed!\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        remove();
        for (String str : array) {
            try {
                BufferedWriter bw;
                FileWriter fw;

                fw = new FileWriter(path, true);
                bw = new BufferedWriter(fw);

                bw.write(str);
                bw.newLine();

                bw.close();
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        }
    public void find(String request){
        String path="C:\\test\\NoteBookKek.txt";
        String readLine;
        int count = 0;
        try {
            BufferedReader b = new BufferedReader(new FileReader(path));
            while ((readLine = b.readLine()) != null) {

                if (readLine.contains(request)) {
                    System.out.println("Here is your result: \n" + readLine + "\n");
                    count++;
                }
            }

            if (count == 0) {
                System.out.println("No results found for " + "'" + request + "'\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void remove(){
        String path="C:\\test\\NoteBookKek.txt";
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(path);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        writer.print("");
        writer.close();
    }
    }



