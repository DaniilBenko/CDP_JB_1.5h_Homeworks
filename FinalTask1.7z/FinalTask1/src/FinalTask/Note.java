package FinalTask;
import java.util.Date;

public class Note {
    private String note;
    private Date data;

    Note(String note, Date data) {
        this.note= note;
        this.data= data;
    }

    @Override
    public String toString() {
        return "Note [note=" + note + ", data=" + data + "]";
    }

}
