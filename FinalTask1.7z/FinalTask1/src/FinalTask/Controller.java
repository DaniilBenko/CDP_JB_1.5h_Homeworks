package FinalTask;

import java.util.Scanner;
import java.util.Date;

public class Controller {
    NoteBook myNoteBook = new NoteBook();

   private boolean running = true;

    public void start() {

        while (running) {
            System.out.println("Select your action: " +
                    "\n1: Add a note" +
                    "\n2: Find a note" +
                    "\n3: Delete a note" +
                    "\n4: Quit app" +
                    "\n>: ");
            Scanner sc = new Scanner(System.in);
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    addNote();
                    break;
                case 2:
                    find();
                    break;
                case 3:
                    delete();
                    break;
                case 4:
                    quit();
                    break;
                default:
                    System.out.println("Invalid option! Try again!\n");
                    break;
            }}}
            private void addNote() {
                Date date = new Date();
                Scanner sc = new Scanner(System.in);
                System.out.println("Input your note: ");
                myNoteBook.add(sc.nextLine(), date);
            }

            private void find() {
                Scanner sc = new Scanner(System.in);
                System.out.println("Input your search request: ");
                myNoteBook.find(sc.nextLine());
            }

            private void delete() {
                Scanner sc = new Scanner(System.in);
                System.out.println("Input number of the note to be removed: ");
                myNoteBook.delete(sc.nextInt());
            }

            private void quit() {
                running = false;
                System.out.println("App closed");
            }

        }
