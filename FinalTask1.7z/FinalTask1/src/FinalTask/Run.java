package FinalTask;

import java.io.IOException;

public class Run {
    public static void main(String[] args) throws IOException {

        Controller contr = new Controller();
        contr.start();

    }
}
